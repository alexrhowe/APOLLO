// specincld.h: standard include files for the spectral code

#ifndef SPECINCLD
#define SPECINCLD

#include <stdio.h>
#include <stdlib.h>
#include <cstdlib>
#include <math.h>
#include <fstream>
#include <iostream>
#include <string>
#include <cstring>
#include <cctype>
#include <exception>
#include <vector>

using namespace std;

#endif
