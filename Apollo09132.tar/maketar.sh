#!/bin/bash

tar -cvf Apollo09132.tar Apollo.makespectrum.py Apollo.pbs Apollo.py Apollo.run FilterList.dat Filters/*.dat Makefile Plot.Apollo.py Plot.Converge.py README.txt examples/*.dat maketar.sh modelspectra/example.spectrum.dat plots/example.TP.png plots/example.basic.png plots/example.fit.png plots/example.gases.png samples/example.dat src/*.h src/*.cpp src/*.py src/*.pxd src/*.pyx
